package com.anuj.gaikaitest.web.rest;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.junit.Before;
import org.junit.Test;

import com.anuj.gaikaitest.Constants;
import com.anuj.gaikaitest.model.Game;
import com.anuj.gaikaitest.scrap.jsoup.GameFetchTask;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * The Class GameRestServiceTest.
 */
public class GameRestServiceTest {

  /** The Constant logger. */
  private static final Logger logger = Logger
      .getLogger(GameRestServiceTest.class);

  /** The game rest service. */
  private static GameRestService gameRestService =
      new GameRestService();

  /** The fetched games. */
  private static List<Game> fetchedGames;

  /** The gson. */
  private static Gson gson = new GsonBuilder().disableHtmlEscaping()
      .create();

  @Before
  public void setup() {
    BasicConfigurator.configure();
    try {
      fetchedGames =
          GameFetchTask.scrapWebData(Constants.GAME_SCRAP_URL);
    } catch (IOException e) {
      logger.error(e.getMessage(), e);
    }
  }

  /**
   * Test get top games.
   * 
   * @throws JSONException the jSON exception
   */
  @Test
  public void testGetTopGames() throws JSONException {
    logger.debug("**** Test case : testGetTopGames() **** ");
    String fetchedGamesByService = gameRestService.getTopGames();
    String fetchedGamesByScrapping = gson.toJson(fetchedGames);
    assert fetchedGamesByScrapping.equals(fetchedGamesByService);
  }

  /**
   * Test get game info.
   * 
   * @throws JSONException the jSON exception
   */
  @Test
  public void testGetGameInfo() throws JSONException {
    logger.debug("**** Test case : testGetGameInfo() **** ");
    String fetchedGamesByScrapping = gson.toJson(fetchedGames);

    JsonParser parser = new JsonParser();
    JsonArray array =
        parser.parse(fetchedGamesByScrapping).getAsJsonArray();

    JsonObject jsonFirstObject =
        gson.fromJson(array.get(0), JsonObject.class);

    String titleFetched =
        jsonFirstObject.get(Constants.GAME_TITLE).toString();
    String title =
        titleFetched.substring(1, titleFetched.length() - 1);

    String fetchedGameByService = gameRestService.getGameInfo(title);
    JSONObject jsonObject = new JSONObject(fetchedGameByService);

    assert title.equals(jsonObject.get(Constants.GAME_TITLE));
  }

  /**
   * Test get game info not present.
   * 
   * @throws JSONException the jSON exception
   */
  @Test
  public void testGetGameInfoNotPresent() throws JSONException {
    logger.debug("**** Test case : testGetGameInfoNotPresent()**** ");
    String fetchedGamesByScrapping = gson.toJson(fetchedGames);

    JsonParser parser = new JsonParser();
    JsonArray array =
        parser.parse(fetchedGamesByScrapping).getAsJsonArray();

    JsonObject jsonFirstObject =
        gson.fromJson(array.get(0), JsonObject.class);

    String titleFetched =
        jsonFirstObject.get(Constants.GAME_TITLE).toString();

    String fetchedGameByService =
        gameRestService.getGameInfo(titleFetched);
    JSONObject jsonObject = new JSONObject(fetchedGameByService);

    assert "N/A".equals(jsonObject.get(Constants.GAME_TITLE));
  }
}
