package com.anuj.gaikaitest;

/**
 * The Class Constants.
 */
public class Constants {

  /** The Constant FETCH_INTERVAL. */
  public static final long FETCH_INTERVAL = 60;

  /** The Constant GAME_TITLE. */
  public static final String GAME_TITLE = "title";

  /** The Constant GAME_SCORE. */
  public static final String GAME_SCORE = "score";

  /** The game scrap url. */
  public static String GAME_SCRAP_URL =
      "http://www.metacritic.com/game/playstation-3";
}
