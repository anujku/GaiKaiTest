package com.anuj.gaikaitest.scrap.jsoup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.anuj.gaikaitest.Constants;
import com.anuj.gaikaitest.model.Game;

/**
 * The Class GameFetchTask.
 */
public class GameFetchTask implements Runnable {

  /** The Constant logger. */
  static final Logger logger = Logger.getLogger(GameFetchTask.class);

  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Runnable#run()
   */
  public void run() {
    BasicConfigurator.configure();
    logger.debug("Fetching Data !");
    GameDataListener.setTopGames(new ArrayList<Game>());
    try {
      GameDataListener
          .setTopGames(scrapWebData(Constants.GAME_SCRAP_URL));
    } catch (IOException e) {
      logger.error(e.getMessage(), e);
    }
  }

  /**
   * Scraps web data.
   * 
   * @param url the url
   * @return the list
   * @throws IOException Signals that an I/O exception has occurred.
   */
  public static List<Game> scrapWebData(String url)
      throws IOException {
    Document doc = Jsoup.connect(url).userAgent("Mozilla").get();
    return parseElements(doc, url);
  }

  /**
   * Parses the elements.
   * 
   * @param doc the doc
   * @param url the url
   * @return the list
   * @throws IOException
   */
  public static List<Game> parseElements(Document doc, String url)
      throws IOException {
    List<Game> games = new ArrayList<Game>();
    doc = Jsoup.connect(url).userAgent("Mozilla").get();
    Game game;
    Elements parents = doc.select("div.main_stats");
    for (Element child : parents) {
      Element label = child.select("h3.product_title").first();
      Element score =
          child.select("span.metascore_w.medium.game").first();
      String gameTitle = label.text();
      long gameScore = Long.parseLong(score.text());
      game = new Game(gameTitle, gameScore);
      games.add(game);
    }

    return games;
  }

}
