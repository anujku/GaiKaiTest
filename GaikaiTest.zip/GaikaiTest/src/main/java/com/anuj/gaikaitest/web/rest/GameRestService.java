package com.anuj.gaikaitest.web.rest;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.anuj.gaikaitest.model.Game;
import com.anuj.gaikaitest.service.GameService;
import com.anuj.gaikaitest.service.GameServiceImpl;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * The Class GameRestService.
 */
@Path("/top")
public class GameRestService {

  /** The game service. */
  private GameService gameService = new GameServiceImpl();

  /** The gson. */
  private Gson gson = new GsonBuilder().disableHtmlEscaping()
      .create();

  /**
   * Gets the top games.
   * 
   * @return the top games
   */
  @GET
  @Path("games")
  @Produces(MediaType.APPLICATION_JSON)
  public String getTopGames() {
    List<Game> games = gameService.getTopGames();
    return gson.toJson(games).toString();
  }

  /**
   * Gets the game info.
   * 
   * @param gameTitle the game title
   * @return the game info
   */
  @GET
  @Path("games/{game_title}")
  @Consumes(MediaType.TEXT_PLAIN)
  @Produces(MediaType.APPLICATION_JSON)
  public String getGameInfo(@PathParam("game_title") String gameTitle) {
    List<Game> games = gameService.getTopGames();
    for (Game game : games) {
      if (game.getTitle().equals(gameTitle)) {
        return gson.toJson(game).toString();
      }
    }
    return gson.toJson(new Game("N/A", 0)).toString();
  }
}
