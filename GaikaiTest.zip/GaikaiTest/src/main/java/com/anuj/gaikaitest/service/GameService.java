package com.anuj.gaikaitest.service;

import java.util.List;

import com.anuj.gaikaitest.model.Game;

public interface GameService {
  public List<Game> getTopGames();
}
