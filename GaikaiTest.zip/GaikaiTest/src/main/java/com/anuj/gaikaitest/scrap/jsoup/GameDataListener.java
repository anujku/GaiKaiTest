package com.anuj.gaikaitest.scrap.jsoup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.anuj.gaikaitest.Constants;
import com.anuj.gaikaitest.model.Game;

/**
 * The Class GameDataScrapListener.
 */
@WebListener
public class GameDataListener implements ServletContextListener {

  /** The top games. */
  private static List<Game> topGames = new ArrayList<Game>();

  /** The scheduler. */
  private ScheduledExecutorService scheduler;

  /*
   * (non-Javadoc)
   * 
   * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
   */
  public void contextInitialized(ServletContextEvent event) {
    scheduler = Executors.newSingleThreadScheduledExecutor();
    scheduler.scheduleAtFixedRate(new GameFetchTask(), 0,
        Constants.FETCH_INTERVAL, TimeUnit.MINUTES);
  }

  /*
   * (non-Javadoc)
   * 
   * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)
   */
  public void contextDestroyed(ServletContextEvent event) {
    scheduler.shutdownNow();
  }

  /**
   * Gets the top games.
   * 
   * @return the top games
   * @throws IOException 
   * @throws InterruptedException
   */
  public static List<Game> getTopGames() throws IOException {
    if (topGames == null || topGames.size() == 0)
      setTopGames(GameFetchTask.scrapWebData(Constants.GAME_SCRAP_URL));
    return topGames;
  }

  /**
   * Sets the top games.
   * 
   * @param topGames the new top games
   */
  public static void setTopGames(List<Game> topGames) {
    GameDataListener.topGames = topGames;
  }

}
