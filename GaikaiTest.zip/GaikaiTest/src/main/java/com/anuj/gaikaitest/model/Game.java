package com.anuj.gaikaitest.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.anuj.gaikaitest.Constants;
import com.google.gson.Gson;

/**
 * The Class Game.
 */
@XmlRootElement
public class Game {

  /** The title. */
  @XmlElement(name = Constants.GAME_TITLE)
  private String title;

  /** The score. */
  @XmlElement(name = Constants.GAME_SCORE)
  private long score;

  /**
   * Instantiates a new game.
   */
  public Game() {
    super();
  }

  /**
   * Instantiates a new game.
   * 
   * @param title the title
   * @param score the score
   */
  public Game(String title, long score) {
    this.title = title;
    this.score = score;
  }

  /**
   * Gets the title.
   * 
   * @return the title
   */
  public String getTitle() {
    return title;
  }

  /**
   * Sets the title.
   * 
   * @param title the new title
   */
  public void setTitle(String title) {
    this.title = title;
  }

  /**
   * Gets the score.
   * 
   * @return the score
   */
  public long getScore() {
    return score;
  }

  /**
   * Sets the score.
   * 
   * @param score the new score
   */
  public void setScore(long score) {
    this.score = score;
  }

  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return new Gson().toJson(this);
  }
}
