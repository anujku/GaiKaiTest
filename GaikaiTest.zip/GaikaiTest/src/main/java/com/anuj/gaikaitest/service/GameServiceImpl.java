package com.anuj.gaikaitest.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.anuj.gaikaitest.model.Game;
import com.anuj.gaikaitest.scrap.jsoup.GameDataListener;

/**
 * The Class GameServiceImpl.
 */
public class GameServiceImpl implements GameService {

  /** The Constant logger. */
  private static final Logger logger = Logger
      .getLogger(GameServiceImpl.class);

  /*
   * (non-Javadoc)
   * 
   * @see com.anuj.gaikaitest.service.GameService#getTopGames()
   */
  public List<Game> getTopGames() {
    try {
      return GameDataListener.getTopGames();
    } catch (IOException e) {
      logger.error(e.getMessage(), e);
      return new ArrayList<Game>();
    }
  }

}
